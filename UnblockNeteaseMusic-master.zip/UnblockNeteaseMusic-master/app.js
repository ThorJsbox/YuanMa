#!/usr/bin/env node
require('./src/app')