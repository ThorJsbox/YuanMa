'use strict';

require('test-y-require');
