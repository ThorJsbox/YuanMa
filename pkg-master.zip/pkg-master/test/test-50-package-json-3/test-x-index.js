/* eslint-disable no-path-concat */

'use strict';

var dataPath = 'test-y-data.json';
var data = require(__dirname + '/' + dataPath);
console.log(data);
