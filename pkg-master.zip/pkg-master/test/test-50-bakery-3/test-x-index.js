'use strict';

console.log('should not be executed');
