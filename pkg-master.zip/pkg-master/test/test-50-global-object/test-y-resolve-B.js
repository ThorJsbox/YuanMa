'use strict';

global.y = 84;
console.log(y); // eslint-disable-line no-undef
