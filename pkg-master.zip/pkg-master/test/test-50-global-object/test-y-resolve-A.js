'use strict';

global.x = 42;
console.log(x); // eslint-disable-line no-undef
