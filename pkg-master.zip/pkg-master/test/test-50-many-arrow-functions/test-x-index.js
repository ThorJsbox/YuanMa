'use strict';

function EventEmitter () {
  this.listeners = [];
}
EventEmitter.prototype.on = function (name, listener) {
  this.listeners.push(listener);
};
EventEmitter.prototype.emit = function (name, data) {
  this.listeners.some((listener) => {
    listener(data);
  });
};
const ee = new EventEmitter();
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.on('message', (data) => {
  console.log(data);
});
ee.emit('message', 'hooray');
