'use strict';

var dataPath = './sub/test-y-require.js';
require(dataPath);
