'use strict';

require('crusader');
