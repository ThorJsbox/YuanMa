'use strict';

require('stylus');
