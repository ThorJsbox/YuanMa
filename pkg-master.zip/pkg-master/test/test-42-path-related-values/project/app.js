'use strict';

require('./module.js');
