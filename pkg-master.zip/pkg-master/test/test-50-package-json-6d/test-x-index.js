'use strict';

require('alpha');
