'use strict';

require('some-package');
