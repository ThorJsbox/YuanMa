'use strict';

var dataPath = 'delta';
require(dataPath);
console.log(global.FOO);
