'use strict';

require('./time.node');
