'use strict';

console.error(__filename);
console.trace();
