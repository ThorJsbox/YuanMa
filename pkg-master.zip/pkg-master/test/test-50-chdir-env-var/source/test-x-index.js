'use strict';

console.log('ok');
