'use strict';

var dataPath = '../test-y-data.json';
var data = require(dataPath);
console.log(data);
