'use strict';

module.exports = 'hello';
