'use strict';

module.exports = 'test-y-fish-A-supfile';
