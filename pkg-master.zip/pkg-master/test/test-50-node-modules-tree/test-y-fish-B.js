'use strict';

module.exports = 'test-y-fish-B-supfile';
