'use strict';

console.log(typeof gc);
