'use strict';

module.exports = function (s) {
  console.log(s);
};
