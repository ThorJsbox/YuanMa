'use strict';

var common = require('../test-y-common.js');

common('I am C');
