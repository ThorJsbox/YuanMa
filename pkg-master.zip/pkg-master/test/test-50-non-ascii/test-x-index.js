'use strict';

console.log(42);
require('./test-y-$$');
