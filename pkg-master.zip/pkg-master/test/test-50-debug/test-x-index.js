'use strict';

setTimeout(function () {
  console.log('ok');
}, 3000);
