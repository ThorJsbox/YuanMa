'use strict';

require('./node_modules/alpha');
