'use strict';

console.log('bar');
