'use strict';

console.log(process.argv[2]);
