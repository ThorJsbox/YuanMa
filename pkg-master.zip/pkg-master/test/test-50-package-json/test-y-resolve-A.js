'use strict';

module.exports = 'test-y-resolve-A';
