'use strict';

require('./test-y-fish-A.js');
require('./test-y-fish-B.js');
