'use strict';

console.log('test-y-fish-B');
console.log(require('./test-y-fish-C'));
