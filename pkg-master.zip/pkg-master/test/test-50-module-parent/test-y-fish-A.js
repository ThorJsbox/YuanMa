'use strict';

console.log('test-y-fish-A');
console.log(require('./test-y-fish-C'));
