# Express-Example

> This example illustrates using `pkg` on a simple Express based app

## Instructions

  1. Run `npm install`
  2. Run `pkg .`

  That's it!

## Post Success Notes

  * Upon success, `pkg` will create an executable named "express-example". This file can be found at the root of the example project directory.
  * To see the app in action, run the executable then navigate to http://localhost:8080/ in your browser.
