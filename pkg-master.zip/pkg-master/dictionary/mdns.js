'use strict';

module.exports = {
  // хоть bindings и объявлен в
  // dependencies, но не используется
};
