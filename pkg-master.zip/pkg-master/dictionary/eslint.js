'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/rules/*.js',
      'lib/formatters/*.js'
    ]
  }
};
