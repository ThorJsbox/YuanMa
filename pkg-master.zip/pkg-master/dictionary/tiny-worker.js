'use strict';

module.exports = {
  pkg: {
    assets: [
      'lib/noop.js'
    ]
  }
};
