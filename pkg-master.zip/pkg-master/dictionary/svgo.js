'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/**/*.js',
      'plugins/*.js'
    ],
    assets: [
      '.svgo.yml'
    ]
  }
};
