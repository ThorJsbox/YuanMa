'use strict';

module.exports = {
  pkg: {
    scripts: [
      'src/node/worker.js'
    ]
  }
};
