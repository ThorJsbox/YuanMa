'use strict';

module.exports = {
  pkg: {
    assets: [
      'data/*'
    ]
  }
};
