'use strict';

module.exports = {
  pkg: {
    scripts: [
      'apis/*.json',
      'lib/services/*.js'
    ]
  }
};
