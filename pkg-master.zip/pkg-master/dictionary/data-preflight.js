'use strict';

module.exports = {
  pkg: {
    assets: [
      'src/view/**/*',
      'src/js/view/**/*'
    ]
  }
};
