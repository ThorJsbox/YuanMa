'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/helper.js'
    ]
  }
};
