'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/arrayParser.js'
    ]
  }
};
