'use strict';

// https://github.com/chjj/blessed/issues/298
module.exports = {
  pkg: {
    scripts: [
      'lib/widgets/*.js'
    ]
  }
};
