'use strict';

module.exports = {
  pkg: {
    assets: [
      'public.pub'
    ]
  }
};
