'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/reload-server.js'
    ]
  }
};
