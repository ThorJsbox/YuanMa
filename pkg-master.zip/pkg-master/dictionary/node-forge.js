'use strict';

module.exports = {
  pkg: {
    scripts: [
      'js/*.js',
      'lib/*.js'
    ]
  }
};
