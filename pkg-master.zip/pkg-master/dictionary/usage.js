'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/providers/*.js'
    ]
  }
};
