'use strict';

module.exports = {
  pkg: {
    assets: [
      'lib/routes.json'
    ]
  }
};
