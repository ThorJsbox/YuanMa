'use strict';

module.exports = {
  pkg: {
    scripts: [
      'apis/**/*.js'
    ]
  }
};
