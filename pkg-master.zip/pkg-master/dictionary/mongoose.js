'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/drivers/node-mongodb-native/*.js'
    ]
  }
};
