'use strict';

/**
 * primitive Binaries must be installed on the system.
 * e.g. go get -u github.com/fogleman/primitive
 */
module.exports = {
};
