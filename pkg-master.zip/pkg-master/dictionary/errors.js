'use strict';

module.exports = {
  pkg: {
    assets: [
      'lib/static/*'
    ]
  }
};
