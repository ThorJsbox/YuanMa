'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/nconf/stores/*.js'
    ]
  }
};
