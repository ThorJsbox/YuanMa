'use strict';

module.exports = {
  pkg: {
    scripts: [
      'dist/**/*.js'
    ]
  }
};
