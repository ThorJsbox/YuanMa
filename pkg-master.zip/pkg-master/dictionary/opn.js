'use strict';

// compatibility with 'open'
module.exports = require('./open.js');
