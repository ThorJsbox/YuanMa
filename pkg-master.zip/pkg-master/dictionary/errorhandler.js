'use strict';

module.exports = {
  pkg: {
    assets: [
      'public/**/*'
    ]
  }
};
