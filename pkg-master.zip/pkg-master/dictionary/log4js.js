'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/appenders/*.js'
    ]
  }
};
