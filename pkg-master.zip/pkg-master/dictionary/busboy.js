'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/types/*.js'
    ]
  }
};
