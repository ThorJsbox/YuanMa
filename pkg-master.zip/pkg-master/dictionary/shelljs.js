'use strict';

module.exports = {
  pkg: {
    scripts: [
      'src/*.js'
    ]
  }
};
