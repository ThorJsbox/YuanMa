'use strict';

module.exports = {
  dependencies: {
    'gulp': undefined,
    'gulp-di': undefined,
    'gulp-istanbul': undefined,
    'gulp-jshint': undefined,
    'gulp-mocha': undefined,
    'mocha': undefined
  },
  pkg: {
    assets: [
      'effective_tld_names.dat'
    ]
  }
};
