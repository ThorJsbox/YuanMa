'use strict';

module.exports = {
  pkg: {
    assets: [
      'lib/data/cacert.pem'
    ]
  }
};
