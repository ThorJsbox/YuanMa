'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/coffee-script/*.js'
    ]
  }
};
