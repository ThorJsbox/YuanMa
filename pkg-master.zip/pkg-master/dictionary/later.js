'use strict';

module.exports = {
  pkg: {
    scripts: [
      'later.js'
    ]
  }
};
