'use strict';

module.exports = {
  pkg: {
    scripts: [
      'machines/*.js'
    ]
  }
};
