'use strict';

module.exports = {
  pkg: {
    assets: [
      'lib/jute/specification.json'
    ]
  }
};
