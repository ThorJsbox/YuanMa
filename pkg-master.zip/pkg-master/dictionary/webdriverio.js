'use strict';

module.exports = {
  pkg: {
    scripts: [
      'build/**/*.js'
    ]
  }
};
