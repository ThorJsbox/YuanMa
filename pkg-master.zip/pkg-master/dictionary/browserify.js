'use strict';

module.exports = {
  pkg: {
    assets: [
      'bin/*.txt'
    ]
  }
};
