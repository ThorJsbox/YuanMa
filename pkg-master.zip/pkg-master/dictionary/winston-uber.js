'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/winston/transports/*.js'
    ]
  }
};
