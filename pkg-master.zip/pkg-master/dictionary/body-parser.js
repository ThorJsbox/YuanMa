'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/types/*.js' // for 1.4-1.13
    ]
  }
};
