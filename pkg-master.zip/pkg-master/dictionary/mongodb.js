'use strict';

module.exports = {
  pkg: {
    scripts: [
      'lib/mongodb/**/*.js'
    ]
  }
};
