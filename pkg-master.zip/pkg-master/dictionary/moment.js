'use strict';

module.exports = {
  pkg: {
    scripts: [
      'locale/*.js'
    ]
  }
};
