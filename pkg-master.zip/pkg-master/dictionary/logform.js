'use strict';

module.exports = {
  pkg: {
    scripts: [
      '*.js'
    ]
  }
};
